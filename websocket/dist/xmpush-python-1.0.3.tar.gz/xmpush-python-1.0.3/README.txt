# xmpush-python

##  安装

运行python setup.py sdist, 在本地生成${project-name}-${version}.tar.gz源码压缩包
运行python setup.py install, 安装到本地
